import { StatsOverview } from './stats/StatsOverview';
import { WeatherWidget } from './WeatherWidget';
import { NoticesPanel } from './NoticesPanel';

export function DashboardMetrics({ data }) {
  return (
    <div className="space-y-6">
      <StatsOverview data={data} />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <WeatherWidget />
        <NoticesPanel />
      </div>
    </div>
  );
}