import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus } from 'lucide-react';
import { ManagementModal } from '@/components/dashboard/ManagementModal';
import { SCULLY_MINE } from '@/services/api';
import { MineAdminEnvironmentalReport } from './MineAdminEnvironmentalReport';
import api from '@/services/api';

export function EnvironmentalDataSection() {
  const [showModal, setShowModal] = useState(false);
  const queryClient = useQueryClient();

  const { data: pollutants } = useQuery({
    queryKey: ['pollutants'],
    queryFn: () => api.endpoints.pollutants.getAll()
  });

  const { data: stations } = useQuery({
    queryKey: ['stations', SCULLY_MINE.province_id],
    queryFn: () => api.endpoints.monitoringStations.getByProvince(SCULLY_MINE.province_id)
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const preparedData = {
        mine: { id: SCULLY_MINE.id },
        pollutant: { id: parseInt(data.pollutantId) },
        monitoringStation: { id: parseInt(data.stationId) },
        measuredValue: parseFloat(data.measuredValue),
        measurementDate: new Date().toISOString(), // Full ISO string for LocalDateTime
        notes: data.notes || ''
      };
      return await api.endpoints.environmentalData.create(preparedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['environmental-data']);
      setShowModal(false);
    }
  });

  const fields = [
    {
      name: 'pollutantId',
      label: 'Pollutant',
      type: 'select',
      required: true,
      options: pollutants?.map(p => ({
        value: p.id.toString(),
        label: `${p.name} (${p.unit}) - Limit: ${p.benchmarkValue}`
      })) || []
    },
    {
      name: 'stationId',
      label: 'Monitoring Station',
      type: 'select',
      required: true,
      options: stations?.map(s => ({
        value: s.id.toString(),
        label: s.location
      })) || []
    },
    {
      name: 'measuredValue',
      label: 'Measured Value',
      type: 'number',
      required: true,
      step: '0.01'
    },
    {
      name: 'notes',
      label: 'Notes',
      type: 'textarea'
    }
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Environmental Report</h2>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center px-4 py-2 bg-amber-500 text-black rounded-lg hover:bg-amber-600"
        >
          <Plus className="h-5 w-5 mr-2" />
          New Environmental Report
        </button>
      </div>

      <MineAdminEnvironmentalReport />

      <ManagementModal
        title="Add Environmental Report"
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        onSubmit={createMutation.mutate}
        fields={fields}
      />
    </div>
  );
}

export default EnvironmentalDataSection;