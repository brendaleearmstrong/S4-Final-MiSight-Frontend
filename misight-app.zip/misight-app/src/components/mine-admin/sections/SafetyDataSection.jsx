import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus } from 'lucide-react';
import { ManagementModal } from '@/components/dashboard/ManagementModal';
import { SCULLY_MINE } from '@/services/api';
import { MineAdminSafetyReport } from './MineSafetyDataReport';
import api from '@/services/api';

export function SafetyDataSection() {
  const [showModal, setShowModal] = useState(false);
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const preparedData = {
        mine: { id: SCULLY_MINE.id },
        lostTimeIncidents: parseInt(data.lostTimeIncidents),
        nearMisses: parseInt(data.nearMisses),
        safetyLevel: data.safetyLevel,
        dateRecorded: new Date().toISOString().split('T')[0],
        notes: data.notes || ''
      };
      return await api.endpoints.safetyData.create(preparedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['safety-data']);
      setShowModal(false);
    }
  });

  const fields = [
    {
      name: 'lostTimeIncidents',
      label: 'Lost Time Incidents',
      type: 'number',
      required: true,
      min: 0
    },
    {
      name: 'nearMisses',
      label: 'Near Misses',
      type: 'number',
      required: true,
      min: 0
    },
    {
      name: 'safetyLevel',
      label: 'Safety Level',
      type: 'select',
      required: true,
      options: [
        { value: 'CRITICAL', label: 'Critical' },
        { value: 'FAIR', label: 'Fair' },
        { value: 'GOOD', label: 'Good' },
        { value: 'EXCELLENT', label: 'Excellent' }
      ]
    },
    {
      name: 'notes',
      label: 'Notes',
      type: 'textarea'
    }
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Safety Report</h2>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center px-4 py-2 bg-amber-500 text-black rounded-lg hover:bg-amber-600"
        >
          <Plus className="h-5 w-5 mr-2" />
          New Safety Report
        </button>
      </div>

      <MineAdminSafetyReport />

      <ManagementModal
        title="Safety Report"
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        onSubmit={createMutation.mutate}
        fields={fields}
      />
    </div>
  );
}