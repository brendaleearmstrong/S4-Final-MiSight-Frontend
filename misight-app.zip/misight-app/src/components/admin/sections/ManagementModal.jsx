import { X } from 'lucide-react';

export function ManagementModal({ 
  type, 
  data = null, 
  onClose, 
  onSubmit,
  additionalFields = {}
}) {
  const getFields = () => {
    switch (type) {
      case 'mines':
        return [
          { name: 'name', label: 'Mine Name', type: 'text' },
          { name: 'location', label: 'Location', type: 'text' },
          { name: 'company', label: 'Company', type: 'text' },
          { 
            name: 'provinceId', 
            label: 'Province', 
            type: 'select',
            options: additionalFields.provinces || []
          },
          {
            name: 'minerals',
            label: 'Minerals',
            type: 'multiselect',
            options: additionalFields.minerals || []
          }
        ];
      case 'minerals':
        return [
          { name: 'name', label: 'Mineral Name', type: 'text' }
        ];
      case 'provinces':
        return [
          { name: 'name', label: 'Province Name', type: 'text' },
          { name: 'abbreviation', label: 'Abbreviation', type: 'text' }
        ];
      case 'users':
        return [
          { name: 'username', label: 'Username', type: 'text' },
          { name: 'password', label: 'Password', type: 'password' },
          { 
            name: 'role', 
            label: 'Role', 
            type: 'select',
            options: [
              { value: 'ADMIN', label: 'Administrator' },
              { value: 'MINE_ADMIN', label: 'Mine Administrator' },
              { value: 'USER', label: 'User' }
            ]
          }
        ];
      default:
        return [];
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const values = Object.fromEntries(formData.entries());
    onSubmit(values);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">
            {data ? 'Edit' : 'Add'} {type.slice(0, -1)}
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {getFields().map((field) => (
            <div key={field.name}>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {field.label}
              </label>
              {field.type === 'select' ? (
                <select
                  name={field.name}
                  defaultValue={data?.[field.name] || ''}
                  className="w-full p-2 border rounded focus:ring-amber-500 focus:border-amber-500"
                >
                  <option value="">Select {field.label}</option>
                  {field.options.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              ) : field.type === 'multiselect' ? (
                <select
                  name={field.name}
                  multiple
                  defaultValue={data?.[field.name] || []}
                  className="w-full p-2 border rounded focus:ring-amber-500 focus:border-amber-500"
                >
                  {field.options.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type={field.type}
                  name={field.name}
                  defaultValue={data?.[field.name] || ''}
                  className="w-full p-2 border rounded focus:ring-amber-500 focus:border-amber-500"
                  required
                />
              )}
            </div>
          ))}

          <div className="flex justify-end gap-2 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-amber-500 text-black rounded hover:bg-amber-600"
            >
              {data ? 'Update' : 'Add'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
