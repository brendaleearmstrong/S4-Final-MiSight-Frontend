import { useState } from 'react';
import { ManagementModal } from '../ManagementModal';
import { DataTable } from '../DataTable';
import { Plus } from 'lucide-react';

export function MinesSection({ data, loading, onAdd, onEdit, onDelete, provinces, minerals }) {
  const [showModal, setShowModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  const columns = [
    { key: 'name', label: 'Mine Name' },
    { key: 'location', label: 'Location' },
    { key: 'company', label: 'Company' },
    { 
      key: 'province', 
      label: 'Province',
      render: (province) => province?.name
    },
    {
      key: 'minerals',
      label: 'Minerals',
      render: (minerals) => minerals?.map(m => m.name).join(', ')
    }
  ];

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Mines Management</h2>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center px-4 py-2 bg-amber-500 text-black rounded-lg hover:bg-amber-600"
        >
          <Plus className="h-5 w-5 mr-2" />
          Add Mine
        </button>
      </div>

      <DataTable
        data={data}
        columns={columns}
        onEdit={(item) => {
          setSelectedItem(item);
          setShowModal(true);
        }}
        onDelete={onDelete}
        loading={loading}
      />

      {showModal && (
        <ManagementModal
          type="mines"
          data={selectedItem}
          onClose={() => {
            setShowModal(false);
            setSelectedItem(null);
          }}
          onSubmit={(data) => {
            if (selectedItem) {
              onEdit(selectedItem.id, data);
            } else {
              onAdd(data);
            }
            setShowModal(false);
            setSelectedItem(null);
          }}
          additionalFields={{
            provinces: provinces?.map(p => ({ value: p.id, label: p.name })),
            minerals: minerals?.map(m => ({ value: m.id, label: m.name }))
          }}
        />
      )}
    </div>
  );
}
