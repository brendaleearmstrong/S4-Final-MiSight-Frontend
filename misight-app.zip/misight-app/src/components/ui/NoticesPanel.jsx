import { Bell, Plus } from 'lucide-react';

export function NoticesPanel() {
  const notices = [
    {
      id: 1,
      title: 'System Update',
      message: 'New environmental monitoring features deployed',
      date: '2024-03-15',
      priority: 'high'
    },
    {
      id: 2,
      title: 'Scheduled Maintenance',
      message: 'System maintenance scheduled for March 20th',
      date: '2024-03-16',
      priority: 'medium'
    },
    {
      id: 3,
      title: 'Policy Update',
      message: 'New safety reporting guidelines now in effect',
      date: '2024-03-17',
      priority: 'high'
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">System Notices</h2>
        <button className="flex items-center px-4 py-2 bg-amber-500 text-black rounded hover:bg-amber-600">
          <Plus className="h-4 w-4 mr-2" />
          Add Notice
        </button>
      </div>

      <div className="space-y-4">
        {notices.map(notice => (
          <div 
            key={notice.id} 
            className={`p-4 rounded-lg border ${
              notice.priority === 'high' 
                ? 'border-red-200 bg-red-50' 
                : 'border-gray-200 bg-gray-50'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold flex items-center">
                <Bell className={`h-4 w-4 mr-2 ${
                  notice.priority === 'high' ? 'text-red-500' : 'text-gray-500'
                }`} />
                {notice.title}
              </h3>
              <span className="text-sm text-gray-500">{notice.date}</span>
            </div>
            <p className="text-gray-600">{notice.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
