import axios from 'axios';

const baseURL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor
api.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

// API endpoints
export const endpoints = {
  // Phase 1 - Implemented APIs
  mines: {
    getAll: () => api.get('/mines'),
    getById: (id) => api.get(`/mines/${id}`),
    create: (data) => api.post('/mines', data),
    update: (id, data) => api.put(`/mines/${id}`, data),
    delete: (id) => api.delete(`/mines/${id}`),
    getMinerals: (id) => api.get(`/mines/${id}/minerals`),
  },
  
  minerals: {
    getAll: () => api.get('/minerals'),
    getById: (id) => api.get(`/minerals/${id}`),
    create: (data) => api.post('/minerals', data),
    update: (id, data) => api.put(`/minerals/${id}`, data),
    delete: (id) => api.delete(`/minerals/${id}`),
  },

  provinces: {
    getAll: () => api.get('/provinces'),
    getById: (id) => api.get(`/provinces/${id}`),
    create: (data) => api.post('/provinces', data),
    update: (id, data) => api.put(`/provinces/${id}`, data),
    delete: (id) => api.delete(`/provinces/${id}`),
  },

  users: {
    getAll: () => api.get('/users'),
    getById: (id) => api.get(`/users/${id}`),
    create: (data) => api.post('/users', data),
    update: (id, data) => api.put(`/users/${id}`, data),
    delete: (id) => api.delete(`/users/${id}`),
  }
};

export default endpoints;