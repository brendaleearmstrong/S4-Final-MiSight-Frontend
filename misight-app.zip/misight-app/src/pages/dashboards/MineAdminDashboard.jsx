import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Building2, Activity, AlertTriangle } from 'lucide-react';
import { SafetyDataSection } from '@/components/mine-admin/sections/SafetyDataSection';
import { EnvironmentalDataSection } from '@/components/mine-admin/sections/EnvironmentalDataSection';
import { MineOverviewSection } from '@/components/mine-admin/sections/MineOverviewSection';
import { WeatherCard } from '@/components/dashboard/WeatherCard';
import { NoticesCard } from '@/components/dashboard/NoticesCard';
import { useAuth } from '@/contexts/AuthContext';
import { SCULLY_MINE } from '@/services/api';

export default function MineAdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const navigate = useNavigate();
  const { user } = useAuth();

  const sidebarItems = [
    { id: 'overview', label: 'Mine Overview', icon: Building2 },
    { id: 'environmental', label: 'Environmental Reports', icon: Activity },
    { id: 'safety', label: 'Safety Reports', icon: AlertTriangle }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'environmental':
        return <EnvironmentalDataSection />;
      case 'safety':
        return <SafetyDataSection />;
      default:
        return <MineOverviewSection />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <img 
                src="/tacora-logo.png" 
                alt="Tacora Resources" 
                className="h-8 object-contain"
              />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Mine Administration</h1>
                <span className="text-sm text-gray-500">
                  {SCULLY_MINE.name} - {SCULLY_MINE.location}
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Logged in as: <span className="font-medium">{user?.username}</span>
              </span>
              <button
                onClick={() => {
                  localStorage.removeItem('user');
                  navigate('/login');
                }}
                className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex min-h-screen">
        <div className="w-64 bg-white shadow-sm border-r">
          <nav className="mt-5 px-2">
            {sidebarItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center px-3 py-2 my-1 text-sm font-medium rounded-md ${
                  activeTab === item.id
                    ? 'bg-amber-500 text-white'
                    : 'text-gray-600 hover:bg-amber-50'
                }`}
              >
                <item.icon className="mr-3 h-5 w-5" />
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="flex-1">
          <main className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <div className="lg:col-span-3">
                {renderContent()}
              </div>
              <div className="space-y-6">
                <WeatherCard />
                <NoticesCard />
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}