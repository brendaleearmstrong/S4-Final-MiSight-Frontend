export default function MineAdminDashboard() {
    return <div className="text-white p-8">Mine Admin Dashboard</div>
  }